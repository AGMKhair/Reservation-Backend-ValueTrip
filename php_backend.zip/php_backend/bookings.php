<?php
// bookings.php
require_once 'db.php';

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $stmt = $pdo->query('SELECT * FROM bookings');
        $bookings = $stmt->fetchAll();
        foreach ($bookings as &$booking) {
            $stmtTickets = $pdo->prepare('SELECT * FROM tickets WHERE booking_id = ?');
            $stmtTickets->execute([$booking['id']]);
            $booking['tickets'] = $stmtTickets->fetchAll();
        }
        sendJson($bookings);
        break;

    case 'POST':
        $input = json_decode(file_get_contents('php://input'), true);

        $passengerName = $input['passengerName'] ?? null;
        $passengerType = $input['passengerType'] ?? null;
        $itineraryReference = $input['itineraryReference'] ?? null;
        $bookingType = $input['bookingType'] ?? null;
        // In the Spring Boot controller, flightType is set from bookingType if provided.
        $flightType = $input['flightType'] ?? $input['bookingType'] ?? null;
        $isSynced = isset($input['isSynced']) ? (int)$input['isSynced'] : null;

        $departure01 = $input['departure01'] ?? null;
        $landing01 = $input['landing01'] ?? null;
        $departure02 = $input['departure02'] ?? null;
        $landing02 = $input['landing02'] ?? null;
        
        $flightId = $input['flightId'] ?? null;
        $createdAt = date('Y-m-d H:i:s');

        $sql = 'INSERT INTO bookings (passenger_name, passenger_type, itinerary_reference, booking_type, flight_type, is_synced, departure_01, landing_01, departure_02, landing_02, flight_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            $passengerName, $passengerType, $itineraryReference, $bookingType, $flightType, $isSynced,
            $departure01, $landing01, $departure02, $landing02, $flightId, $createdAt
        ]);
        
        $newId = $pdo->lastInsertId();

        $stmt = $pdo->prepare('SELECT * FROM bookings WHERE id = ?');
        $stmt->execute([$newId]);
        sendJson($stmt->fetch());
        break;

    default:
        sendJson("Method not allowed", 405);
        break;
}
?>
